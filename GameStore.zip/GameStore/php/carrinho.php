<?php

session_start();
if (!isset($_SESSION['itens'])) //se a sessão não começar
{
    $_SESSION['itens'] = array();
} //caso o usuário entre sem querer e não tiver nada, cria um array.

if (isset($_GET['add']) && $_GET['add'] == "carrinho") {
    //Adiciona ao carrinho
    $idProduto = $_GET['id'];
    if (!isset($_SESSION['itens'][$idProduto])) // se não existir o produto adicionado
    {
        $_SESSION['itens'][$idProduto] = 1;
    } else {
        $_SESSION['itens'][$idProduto] += 1;
    } //para adicionar o produto pela primeira vez, e depois mais vezes.
}
//exibe o carrinho



?>
<!DOCTYPE html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../estilos/stylecadastro.css">


</head>

<body>

    <div class='container'>

        <div class='card'>
            <h1> Carrinho </h1>
            <div class='justify-center'>

                <?php
                if (count($_SESSION['itens']) == 0) {
                ?>
                <?php echo '<h2 style="color: white;">Carrinho Vazio<br><br><a href="index.php"<h2 style="color: white;">Adicionar itens</a><a> </a>'; //volta pra index
                } else {

                    $_SESSION['dados'] = array(); //transforma em dados numa variavel vazia pra preencher
                
                    $conexao = new PDO('mysql:host=localhost;dbname=meusprodutos', "root", "");

                }
                ?>
                
                <h3 style="color: white">
                    <?php
                    foreach ($_SESSION['itens'] as $idProduto => $quantidade) {

                        $select = $conexao->prepare("SELECT * FROM produtos WHERE id=?");
                        $select->bindParam(1, $idProduto);
                        $select->execute();
                        $produtos = $select->fetchAll();
                        $total = $produtos[0]["preco"];
                        echo
                            'Nome: ' . $produtos[0]["nome"] . '<br/>
        Preço: ' . number_format($produtos[0]["preco"], 2, ",", ".") . '<br/>
        Total: ' . number_format($total, 2, ",", ".") . '<br/>
        <a href="remover.php?remover=carrinho&id=' . $idProduto . '">Remover</a>
        <hr><br><br><br>   
        
       ';



                        //array_push para preencher o array vazio de dados
                        array_push(
                            $_SESSION['dados'],
                            array(
                                'id_produto' => $idProduto,
                                'preco' => $produtos[0]['preco'],
                                'total' => $total
                            )
                        ); //Arraypush
                    

                    }

                    ?>
                </h3>




            </div>
   




        </div>
        
        <div class="btnln">
            
            <a href="../php/index.php"><button>Finalizar</button></a>

    </div>

</body>

</html>