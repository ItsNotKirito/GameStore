<?php
    session_start();

    foreach($_SESSION['dados'] as $produtos){
        $conexao = new PDO('mysql:host=localhost;dbname=meusprodutos',"root","");
        $insert = $conexao->prepare("INSERT INTO pedidos () VALUES (NULL,?,?,?)");
        $insert->bindParam(1,$produtos['id_produto']);
        $insert->bindParam(2,$produtos['preco']);
        $insert->bindParam(3,$produtos['total']);
        $insert->execute();
            header('Location: ../php/index.php'.$url);
            die();
        
    }
