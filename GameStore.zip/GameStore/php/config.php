<?php

    $dbHost = 'Localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName = 'formulario-gamestore';


    $conexao = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);


  //  if($conexao->connect_errno){
  //      echo "erro";
  //  }
  //  else
 //   {
 //      echo "Deu certo";
  //  }


?>

