<?php
    $nome = $_POST["nome"];
    $usuario = $_POST["usuario"];
    $email = $_POST["email"];
    $senha = $_POST["senha"];


    $con =  mysqli_connect("localhost", "root","root", "users-gamestore");

    mysqli_query($con, "INSERT INTO clientes (Nome, Usuario, Email, Senha) VALUES('$nome','$usuario','$email','$senha')");
    
    
?>



