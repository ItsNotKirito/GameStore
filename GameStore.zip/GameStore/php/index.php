<?php
    $conexao = new PDO('mysql:host=localhost;dbname=meusprodutos',"root","");

    $select = $conexao->prepare("SELECT * FROM produtos");
    $select->execute();
    $fetch = $select->fetchAll(); //traz todos os valores do banco de dados


?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generic GameStore</title>
    <link rel="stylesheet" href="../estilos/estilogames.css">
</head>
<body>
    <header>
        <nav>
            <h1 class="titulo">Generic GameStore</h1>
        </nav>
    </header>
    <div class="games">
        <div class="cards">
            <table class="table">
                <tr>
            <?php 
                foreach($fetch as $produto){ //transforma os itens do fetch na variavel produto
                    ?>
                    <td>
                    <div class="cardgame">
                    <h2><?php
                    echo $produto['nome']?></h2>
                    <img src=<?php echo "../imagens/".$produto['id'].".jpg"
                    ?> alt="">
                    <h3><?php
                    echo 'Preço: '.$produto['preco']?></h3>    
                    <a href=<?php echo "carrinho.php?add=carrinho&id=".$produto['id'] ?>><button>Adicionar ao Carrinho</button></a>
                </div>
                    </td>
                    <?php 
                    $conta = $produto['id'];
                    if ($conta % 3 == 0){
                        echo "</tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr>
                        </tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr>
                        </tr><tr></tr><tr></tr><tr>" ;
                    }
                }
            ?>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>