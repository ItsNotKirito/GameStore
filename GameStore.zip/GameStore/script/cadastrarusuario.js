$(document).ready(function () {
    fLocalEventosClick();
});

function fLocalEventosClick() {
    $("#salvarusuario").click(function () {
        var nome = document.getElementById("nome").value.trim();
        var usuario = document.getElementById("usuario").value.trim();
        var email = document.getElementById("email").value.trim();
        var senha = document.getElementById("senha").value.trim();
        var confirmarsenha = document.getElementById("confirmarsenha").value.trim();
        

        document.getElementById("tela-cadastro").style.height = "1690px"

        if (nome.length <= 3) {
            document.getElementById('erronome').innerHTML = `<p>ERRO! Nome inválido</p>`
            document.getElementById("nome").style.border = "solid 1px red"

        }
        if (usuario.length <= 3) {
            document.getElementById('errousuario').innerHTML = `<p>ERRO! Usuario inválido</p>`
            document.getElementById("usuario").style.border = "solid 1px red"

        }
        if (email == "") {
            document.getElementById('erroemail').innerHTML = `<p>ERRO! E-mail inválido</p>`
            document.getElementById("email").style.border = "solid 1px red"

        }
        if (senha == "") {
            document.getElementById('errosenha').innerHTML = `<p>ERRO! Senha inválida</p>`
            document.getElementById("senha").style.border = "solid 1px red"
        }
        if (confirmarsenha == "" || confirmarsenha != senha) {
            document.getElementById('erroconfirmarsenha').innerHTML = `<p>ERRO! Senhas diferentes</p>`
            document.getElementById("confirmarsenha").style.border = "solid 1px red"
        }

        if (nome.length > 3 && usuario != "" && confirmarsenha == senha) {
            fLocalComunicaServidor("adicionarusuario")
            alert("CADASTRO REALIZADO COM SUCESSO")
            window.location.href = "login.html"
            return false;
        }

    });
}


function fLocalComunicaServidor(arquivo) {

    var valores = $("form").serialize();
    $.ajax({

        type: "POST",
        dataType: "json",
        data: valores,
        url: "../php/" + arquivo + ".php",
        success: function (retorno) {

        }
    });
}
function mostrarsenha() {
    var senha = document.getElementById("senha")
    var confirmarsenha = document.getElementById("confirmarsenha")
    if (senha.getAttribute("type") == "password") {
        senha.setAttribute("type", "text");
        confirmarsenha.setAttribute("type", "text");
    } else {
        senha.setAttribute("type", "password");
        confirmarsenha.setAttribute("type", "password");
    }
}
