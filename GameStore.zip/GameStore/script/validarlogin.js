function validarlogin() {

    var login = document.getElementById('login').value;
    var senha = document.getElementById('senha').value;

    if (login == "admin" && senha == "senha") {
        alert('Sucesso');
    } else {
        alert('Usuario ou Senha inválidos.')
    }

}

function logar(){
    window.location = "../paginas/principal.html";
}

function carrinho(){
    window.location = "../php/carrinho.php";
}